package lib;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/reserve")
public class ReservationServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private static final String JDBC_URL = "jdbc:h2:tcp://localhost/~/jwbookdb";
    private static final String JDBC_USER = "jwbook";
    private static final String JDBC_PASSWORD = "1234";

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String seatNumber = request.getParameter("seat_number");
        String name = request.getParameter("name");

        String message = null;
        try {
            Class.forName("org.h2.Driver");
            try (Connection connection = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD)) {
                String sql = "INSERT INTO Reservations (seat_number, name) VALUES (?, ?)";
                try (PreparedStatement statement = connection.prepareStatement(sql)) {
                    statement.setInt(1, Integer.parseInt(seatNumber));
                    statement.setString(2, name);
                    statement.executeUpdate();
                }
            }
        } catch (Exception e) {
            message = "예약 처리 중 오류가 발생했습니다.";
            e.printStackTrace();
        }

        if (message != null) {
            // 실패했을 때만 메시지를 전달
            response.sendRedirect(request.getContextPath() + "/project/lib//reservationForm.jsp?message=" + java.net.URLEncoder.encode(message, "UTF-8"));
        } else {
            // 성공 시 메시지 없이 리디렉트
            response.sendRedirect(request.getContextPath() + "/project/lib/reservationForm.jsp");
        }
    }
}
