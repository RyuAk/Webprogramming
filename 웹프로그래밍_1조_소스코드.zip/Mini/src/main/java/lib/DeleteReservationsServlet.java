package lib;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/deleteReservations")
public class DeleteReservationsServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private static final String JDBC_URL = "jdbc:h2:tcp://localhost/~/jwbookdb";
    private static final String JDBC_USER = "jwbook";
    private static final String JDBC_PASSWORD = "1234";

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String[] reservationIds = request.getParameterValues("reservationIds");

        if (reservationIds != null && reservationIds.length > 0) {
            try {
                Class.forName("org.h2.Driver");
                try (Connection connection = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD)) {
                    String sql = "DELETE FROM Reservations WHERE id = ?";
                    try (PreparedStatement statement = connection.prepareStatement(sql)) {
                        for (String id : reservationIds) {
                            statement.setInt(1, Integer.parseInt(id));
                            statement.executeUpdate();
                        }
                    }
                }
                response.setStatus(HttpServletResponse.SC_OK); // Success response
            } catch (ClassNotFoundException | SQLException e) {
                e.printStackTrace();
                response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR); // Internal server error response
            }
        } else {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST); // Bad request response
        }
    }
}