package lib;

public class Reservation {
    private int id;
    private int seatNumber;
    private String name;

    public Reservation(int id, int seatNumber, String name) {
        this.id = id;
        this.seatNumber = seatNumber;
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public int getSeatNumber() {
        return seatNumber;
    }

    public String getName() {
        return name;
    }
}
