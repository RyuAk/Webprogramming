package my.book;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BookDAO {
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    String url, user, pass;

    public BookDAO() {
        try {
            Class.forName("org.h2.Driver");
        } catch (ClassNotFoundException e) { 
            e.printStackTrace();
        }

        url = "jdbc:h2:tcp://localhost/~/jwbookdb";
        user = "jwbook";
        pass = "1234";
    }
    
    public int insertBook(BookDTO dto) throws SQLException {
        String sql = "insert into book (name, author, publisher, price, enterdate) values (?, ?, ?, ?, CURRENT_TIMESTAMP)"; 
        try {
            con = DriverManager.getConnection(url, user, pass);
            ps = con.prepareStatement(sql);
            ps.setString(1, dto.getName());
            ps.setString(2, dto.getAuthor());
            ps.setString(3, dto.getPublisher());
            ps.setInt(4, dto.getPrice());
            int res = ps.executeUpdate();
            return res;
        } finally { 
            if (ps != null)
                ps.close();
            if (con != null)
                con.close();
        }
    }
    
    public int deleteBook(String name) throws SQLException {
        String sql = "delete from book where name=?";
        try {
            con = DriverManager.getConnection(url, user, pass);
            ps = con.prepareStatement(sql);
            ps.setString(1, name);
            int res = ps.executeUpdate();
            return res;
        } finally {
            if (ps != null)
                ps.close();
            if (con != null)
                con.close();
        }
    }
    
    public List<BookDTO> listBook() throws SQLException {
        String sql = "select * from book";
        try {
            con = DriverManager.getConnection(url, user, pass);
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();

            List<BookDTO> list = makeList(rs); 
            return list;
        } finally {
            if (ps != null)
                ps.close();
            if (con != null)
                con.close();
            if (rs != null)
                rs.close();
        }   
    }

    public List<BookDTO> makeList(ResultSet rs) throws SQLException {
        List<BookDTO> list = new ArrayList<BookDTO>();
        while (rs.next()) {
            BookDTO dto = new BookDTO();
            dto.setName(rs.getString("name"));
            dto.setAuthor(rs.getString("author"));
            dto.setPublisher(rs.getString("publisher"));
            dto.setPrice(rs.getInt("price"));
            dto.setEnterdate(rs.getTimestamp("enterdate")); // 변경됨
            list.add(dto);
        }
        return list;
    }
    
    public List<BookDTO> findBook(String find, String findString) throws SQLException {
        String sql = "select * from book where " + find + "=?";
        try {
            con = DriverManager.getConnection(url, user, pass);
            ps = con.prepareStatement(sql);
            ps.setString(1, findString);
            rs = ps.executeQuery();
            List<BookDTO> list = makeList(rs);

            return list;
        } finally {
            if (ps != null)
                ps.close();
            if (con != null)
                con.close();
            if (rs != null)
                rs.close();
        }
    }
}
