package lib;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/reserve")
public class ReservationServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private static final String JDBC_URL = "jdbc:h2:tcp://localhost/~/jwbookdb";
    private static final String JDBC_USER = "jwbook";
    private static final String JDBC_PASSWORD = "1234";

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int seatNumber = Integer.parseInt(request.getParameter("seat_number"));
        String name = request.getParameter("name");
        String message = "";

        try {
            Class.forName("org.h2.Driver");
            try (Connection connection = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD)) {
                String sql = "INSERT INTO Reservations (seat_number, name) VALUES (?, ?)";
                try (PreparedStatement statement = connection.prepareStatement(sql)) {
                    statement.setInt(1, seatNumber);
                    statement.setString(2, name);
                    int rowsInserted = statement.executeUpdate();
                    if (rowsInserted > 0) {
                        message = "예약이 성공적으로 완료되었습니다.";
                    } else {
                        message = "예약에 실패하였습니다.";
                    }
                }
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            message = "예약 요청 중 오류가 발생했습니다.";
        }

        request.setAttribute("message", message);
        request.getRequestDispatcher("/lib/reservationForm.jsp").forward(request, response);
    }
}
